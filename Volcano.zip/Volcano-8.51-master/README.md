# Main
Discord: "@jyzo.",
**STAR FOR MORE UPDATES**
</br>
**PLEASE NOTE: THIS SOURCE IS GONNA BE RARELY UPDATED**
</br>

# Features
- Farming
- Building/Editing
- Proper Teams 
- Different ltms support
- Respawning
- Proper hooking
- Vehicles
- Lategame
- Emoting
- Looting (unproper but idgaf)
- AutoPickup (unfinished yet)
- Change Teams in Playground etc...
- MCP (bugged)
 
# Credits
*Dumped SDK with*: [Dumper-7](https://github.com/Encryqed/Dumper-7)

# Contribution
Send a pull request, if it has anything new or a fix. It'll be merged into the main
