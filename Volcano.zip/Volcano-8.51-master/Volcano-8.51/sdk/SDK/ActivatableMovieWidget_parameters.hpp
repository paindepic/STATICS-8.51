#pragma once

// Dumped with Dumper-7!

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

#include "../SDK.hpp"

namespace SDK
{
namespace Params
{
//---------------------------------------------------------------------------------------------------------------------
// PARAMETERS
//---------------------------------------------------------------------------------------------------------------------

// 0x0 (0x0 - 0x0)
// Function ActivatableMovieWidget.ActivatableMovieWidget_C.OnActivated
struct UActivatableMovieWidget_C_OnActivated_Params
{
public:
};

// 0x0 (0x0 - 0x0)
// Function ActivatableMovieWidget.ActivatableMovieWidget_C.OnDeactivated
struct UActivatableMovieWidget_C_OnDeactivated_Params
{
public:
};

// 0x4 (0x4 - 0x0)
// Function ActivatableMovieWidget.ActivatableMovieWidget_C.ExecuteUbergraph_ActivatableMovieWidget
struct UActivatableMovieWidget_C_ExecuteUbergraph_ActivatableMovieWidget_Params
{
public:
	int32                                        EntryPoint;                                        // 0x0(0x4)(BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}
}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
