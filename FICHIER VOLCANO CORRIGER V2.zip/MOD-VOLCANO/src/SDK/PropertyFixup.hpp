#pragma once

// Definitions for missing Properties

class UMulticastInlineDelegateProperty_
{
	unsigned __int8 Pad[0x10];
};

class UDelegateProperty_
{
	unsigned __int8 Pad[0x10];
};

class UInterfaceProperty_
{
	unsigned __int8 Pad[0x10];
};

class UMulticastSparseDelegateProperty_
{
	unsigned __int8 Pad[0x1];
};

